from django.shortcuts import render,redirect
from .forms import FoodModelForm
from .models import Food
from django.http import HttpResponse
# Create your views here.

def addorderview(request):
    form = FoodModelForm()
    if request.method == 'POST':
        form = FoodModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/show")
    return render(request,"app1/add_order.html",{"form":form})

def showorderview(request):
    obj = Food.objects.all()
    return render(request,"app1/show_order.html",{"obj":obj})

def updateorderview(request,i):
    f = Food.objects.get(id=i)
    form = FoodModelForm(instance=f)
    if request.method == 'POST':
        form = FoodModelForm(request.POST,instance=f)
        if form.is_valid():
            form.save()
            return redirect("/show")
    return render(request,"app1/add_order.html",{"form":form})

def deleteorderview(request,i):
    obj = Food.objects.get(id=i)
    if request.method == 'POST':
        obj.delete()
    return render(request,"app1/delete_order.html",{"obj":obj})

