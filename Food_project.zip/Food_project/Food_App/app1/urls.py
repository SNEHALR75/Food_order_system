

from django.urls import path
from .import views


urlpatterns =[
    path("add/",views.addorderview),
    path("show/",views.showorderview),
    path("update/<i>",views.updateorderview),
    path("delete/<i>",views.deleteorderview),
]
